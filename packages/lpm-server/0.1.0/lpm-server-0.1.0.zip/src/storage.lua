local fs = require("fs")
local path = require("path")
local metadata = require("metadata")
local toml = require("toml")

local M = {}

local STORAGE_DIR = "packages"

function M.init()
    if not fs.exists(STORAGE_DIR) then
        fs.mkdir_p(STORAGE_DIR)
    end
end

function M.get_package_path(name, version)
    return path.join(STORAGE_DIR, name, version)
end

function M.get_package_file(name, version)
    local pkg_path = M.get_package_path(name, version)
    return path.join(pkg_path, name .. "-" .. version .. ".zip")
end

function M.get_package_metadata_file(name, version)
    local pkg_path = M.get_package_path(name, version)
    return path.join(pkg_path, "package.toml")
end

function M.save_package(name, version, data)
    local pkg_path = M.get_package_path(name, version)
    
    if not fs.exists(pkg_path) then
        fs.mkdir_p(pkg_path)
    end
    
    local file_path = M.get_package_file(name, version)
    return fs.write_file(file_path, data)
end

function M.update_package(name, version, data)
    local file_path = M.get_package_file(name, version)
    
    if not fs.exists(file_path) then
        return false
    end
    
    return fs.write_file(file_path, data)
end

function M.delete_package(name, version)
    local pkg_path = M.get_package_path(name, version)
    
    if not fs.exists(pkg_path) then
        return false
    end
    
    return fs.remove(pkg_path)
end

function M.load_package(name, version)
    local file_path = M.get_package_file(name, version)
    
    if not fs.exists(file_path) then
        return nil
    end
    
    return fs.read_file(file_path)
end

function M.get_package_info(name, version)
    local pkg_path = M.get_package_path(name, version)
    
    if not fs.exists(pkg_path) then
        return nil
    end
    
    local metadata_file = M.get_package_metadata_file(name, version)
    local metadata_content = nil
    
    if fs.exists(metadata_file) then
        metadata_content = fs.read_file(metadata_file)
    end
    
    local file_path = M.get_package_file(name, version)
    local file_size = 0
    if fs.exists(file_path) then
        local p = io.popen("stat -c %s " .. file_path .. " 2>/dev/null")
        if p then
            file_size = tonumber(p:read("*n")) or 0
            p:close()
        end
    end
    
    return {
        name = name,
        version = version,
        metadata = metadata_content and toml.decode(metadata_content) or nil,
        size = file_size,
        path = pkg_path
    }
end

function M.list_packages()
    local packages = {}
    
    if not fs.exists(STORAGE_DIR) then
        return packages
    end
    
    local names = fs.list_dir(STORAGE_DIR)
    for _, name in ipairs(names) do
        local name_path = path.join(STORAGE_DIR, name)
        if fs.is_dir(name_path) then
            local versions = fs.list_dir(name_path)
            for _, version in ipairs(versions) do
                if fs.is_dir(path.join(name_path, version)) then
                    table.insert(packages, {
                        name = name,
                        version = version
                    })
                end
            end
        end
    end
    
    return packages
end

function M.list_versions(name)
    local name_path = path.join(STORAGE_DIR, name)
    
    if not fs.exists(name_path) or not fs.is_dir(name_path) then
        return {}
    end
    
    local versions = {}
    local version_dirs = fs.list_dir(name_path)
    for _, version in ipairs(version_dirs) do
        if fs.is_dir(path.join(name_path, version)) then
            table.insert(versions, version)
        end
    end
    
    return versions
end

return M
