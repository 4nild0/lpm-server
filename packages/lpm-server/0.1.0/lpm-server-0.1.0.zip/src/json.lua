local json = {}

local function escape_string(str)
    return str:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\n", "\\n"):gsub("\r", "\\r"):gsub("\t", "\\t")
end

local function encode_value(value)
    local vtype = type(value)
    
    if vtype == "string" then
        return '"' .. escape_string(value) .. '"'
    elseif vtype == "number" then
        return tostring(value)
    elseif vtype == "boolean" then
        return value and "true" or "false"
    elseif vtype == "nil" then
        return "null"
    elseif vtype == "table" then
        local is_array = true
        local max_index = 0
        local count = 0
        
        for k, v in pairs(value) do
            count = count + 1
            if type(k) ~= "number" then
                is_array = false
                break
            end
            if k > max_index then
                max_index = k
            end
        end
        
        if is_array and max_index == count then
            local items = {}
            for i = 1, max_index do
                table.insert(items, encode_value(value[i]))
            end
            return "[" .. table.concat(items, ",") .. "]"
        else
            local items = {}
            for k, v in pairs(value) do
                table.insert(items, '"' .. tostring(k) .. '":' .. encode_value(v))
            end
            return "{" .. table.concat(items, ",") .. "}"
        end
    end
    
    return "null"
end

function json.encode(value)
    return encode_value(value)
end

local function decode_value(str, pos)
    pos = pos or 1
    
    while pos <= #str and str:sub(pos, pos):match("%s") do
        pos = pos + 1
    end
    
    if pos > #str then
        return nil, pos
    end
    
    local char = str:sub(pos, pos)
    
    if char == '"' then
        local start = pos + 1
        local result = ""
        pos = start
        
        while pos <= #str do
            local c = str:sub(pos, pos)
            if c == '\\' and pos < #str then
                pos = pos + 1
                local next_char = str:sub(pos, pos)
                if next_char == 'n' then
                    result = result .. "\n"
                elseif next_char == 'r' then
                    result = result .. "\r"
                elseif next_char == 't' then
                    result = result .. "\t"
                elseif next_char == '\\' then
                    result = result .. "\\"
                elseif next_char == '"' then
                    result = result .. '"'
                else
                    result = result .. next_char
                end
            elseif c == '"' then
                return result, pos + 1
            else
                result = result .. c
            end
            pos = pos + 1
        end
        return result, pos
    elseif char == '{' then
        local result = {}
        pos = pos + 1
        
        while pos <= #str do
            while pos <= #str and str:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
            
            if str:sub(pos, pos) == '}' then
                return result, pos + 1
            end
            
            local key, new_pos = decode_value(str, pos)
            if not key then break end
            pos = new_pos
            
            while pos <= #str and str:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
            
            if str:sub(pos, pos) ~= ':' then break end
            pos = pos + 1
            
            local value, new_pos = decode_value(str, pos)
            if not value then break end
            pos = new_pos
            
            result[key] = value
            
            while pos <= #str and str:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
            
            if str:sub(pos, pos) == ',' then
                pos = pos + 1
            end
        end
        return result, pos
    elseif char == '[' then
        local result = {}
        pos = pos + 1
        local index = 1
        
        while pos <= #str do
            while pos <= #str and str:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
            
            if str:sub(pos, pos) == ']' then
                return result, pos + 1
            end
            
            local value, new_pos = decode_value(str, pos)
            if not value then break end
            pos = new_pos
            
            result[index] = value
            index = index + 1
            
            while pos <= #str and str:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
            
            if str:sub(pos, pos) == ',' then
                pos = pos + 1
            end
        end
        return result, pos
    elseif char:match("%d") or char == '-' then
        local start = pos
        while pos <= #str and (str:sub(pos, pos):match("%d") or str:sub(pos, pos) == '.' or str:sub(pos, pos) == '-' or str:sub(pos, pos) == 'e' or str:sub(pos, pos) == 'E' or str:sub(pos, pos) == '+') do
            pos = pos + 1
        end
        local num_str = str:sub(start, pos - 1)
        local num = tonumber(num_str)
        return num, pos
    elseif str:sub(pos, pos + 3) == "true" then
        return true, pos + 4
    elseif str:sub(pos, pos + 4) == "false" then
        return false, pos + 5
    elseif str:sub(pos, pos + 3) == "null" then
        return nil, pos + 4
    end
    
    return nil, pos
end

function json.decode(str)
    local value, pos = decode_value(str, 1)
    return value
end

return json

