local storage = require("storage")
local auth = require("auth")
local server = require("server")
local logger = require("logger")
local json = require("json")

local M = {}

function M.list(request, params)
    local packages = storage.list_packages()
    
    local result = {}
    for _, pkg in ipairs(packages) do
        table.insert(result, {
            name = pkg.name,
            version = pkg.version
        })
    end
    
    local body = json.encode(result)
    return server.create_response(200, body, "application/json")
end

function M.get(request, params)
    local name = params.name
    local version = params.version
    
    if not name or not version then
        return server.create_response(400, "Name and version required")
    end
    
    logger.info("Get package: " .. name .. "@" .. version)
    
    local info = storage.get_package_info(name, version)
    
    if not info then
        return server.create_response(404, json.encode({error = "Package not found"}), "application/json")
    end
    
    local body = json.encode(info)
    return server.create_response(200, body, "application/json")
end

function M.download(request, params)
    local name = params.name
    local version = params.version
    
    logger.info("Download request: " .. name .. "@" .. version)
    
    local data = storage.load_package(name, version)
    
    if not data then
        return server.create_response(404, "Package not found")
    end
    
    return server.create_response(200, data, "application/zip")
end

function M.create(request, params)
    local name = params.name
    local version = params.version
    
    if not name or not version then
        return server.create_response(400, "Name and version required")
    end
    
    local token = auth.extract_from_header(request.headers["authorization"])
    
    if not auth.validate(token) then
        return server.create_response(401, json.encode({error = "Unauthorized"}), "application/json")
    end
    
    logger.info("Create package: " .. name .. "@" .. version)
    
    if not request.body or #request.body == 0 then
        return server.create_response(400, json.encode({error = "Package data required"}), "application/json")
    end
    
    local success = storage.save_package(name, version, request.body)
    
    if not success then
        return server.create_response(500, json.encode({error = "Failed to save package"}), "application/json")
    end
    
    local info = storage.get_package_info(name, version)
    local body = json.encode({message = "Package created", package = info})
    return server.create_response(201, body, "application/json")
end

function M.update(request, params)
    local name = params.name
    local version = params.version
    
    if not name or not version then
        return server.create_response(400, "Name and version required")
    end
    
    local token = auth.extract_from_header(request.headers["authorization"])
    
    if not auth.validate(token) then
        return server.create_response(401, json.encode({error = "Unauthorized"}), "application/json")
    end
    
    logger.info("Update package: " .. name .. "@" .. version)
    
    if not request.body or #request.body == 0 then
        return server.create_response(400, json.encode({error = "Package data required"}), "application/json")
    end
    
    local success = storage.update_package(name, version, request.body)
    
    if not success then
        return server.create_response(404, json.encode({error = "Package not found"}), "application/json")
    end
    
    local info = storage.get_package_info(name, version)
    local body = json.encode({message = "Package updated", package = info})
    return server.create_response(200, body, "application/json")
end

function M.delete(request, params)
    local name = params.name
    local version = params.version
    
    if not name or not version then
        return server.create_response(400, "Name and version required")
    end
    
    local token = auth.extract_from_header(request.headers["authorization"])
    
    if not auth.validate(token) then
        return server.create_response(401, json.encode({error = "Unauthorized"}), "application/json")
    end
    
    logger.info("Delete package: " .. name .. "@" .. version)
    
    local success = storage.delete_package(name, version)
    
    if not success then
        return server.create_response(404, json.encode({error = "Package not found"}), "application/json")
    end
    
    local body = json.encode({message = "Package deleted"})
    return server.create_response(200, body, "application/json")
end

function M.list_versions(request, params)
    local name = params.name
    
    if not name then
        return server.create_response(400, "Name required")
    end
    
    local versions = storage.list_versions(name)
    local body = json.encode({name = name, versions = versions})
    return server.create_response(200, body, "application/json")
end

return M
