

package.path = package.path .. ";./src/?.lua"

local core = require("init")
local fs = core.fs
local path = core.path
local toml = core.toml
local metadata = core.metadata

local function assert_eq(a, b, msg)
    if a ~= b then
        error(string.format("%s: expected %s, got %s", msg or "Assertion failed", tostring(b), tostring(a)))
    end
end

local function test_path()
    print("Testing path...")
    assert_eq(path.join("a", "b"), "a/b", "path.join failed")
    assert_eq(path.normalize("a/../b"), "b", "path.normalize failed")
    assert_eq(path.dirname("/a/b/c"), "/a/b", "path.dirname failed")
    assert_eq(path.basename("/a/b/c"), "c", "path.basename failed")
end

local function test_fs()
    print("Testing fs...")
    local test_dir = "test_fs_dir"
    local test_file = path.join(test_dir, "test.txt")
    
    if fs.exists(test_dir) then fs.remove(test_dir) end
    
    assert_eq(fs.mkdir(test_dir), true, "fs.mkdir failed")
    assert_eq(fs.exists(test_dir), true, "fs.exists dir failed")
    
    assert_eq(fs.write_file(test_file, "hello"), true, "fs.write_file failed")
    assert_eq(fs.exists(test_file), true, "fs.exists file failed")
    assert_eq(fs.read_file(test_file), "hello", "fs.read_file failed")
    
    fs.remove(test_dir)
    assert_eq(fs.exists(test_dir), false, "fs.remove failed")
end

local function test_toml()
    print("Testing toml...")
    local data = {
        name = "test",
        version = "1.0.0",
        deps = {
            lua = "5.4"
        }
    }
    local encoded = toml.encode(data)
    local decoded = toml.decode(encoded)
    
    assert_eq(decoded.name, data.name, "toml name mismatch")
    assert_eq(decoded.version, data.version, "toml version mismatch")
    assert_eq(decoded.deps.lua, data.deps.lua, "toml deps mismatch")
end

local function test_metadata()
    print("Testing metadata...")
    local data = metadata.load(".")
    assert_eq(data.name, "lpm-core", "metadata name mismatch")
    assert_eq(data.version, "0.1.0", "metadata version mismatch")
end


test_path()
test_fs()
test_toml()
test_metadata()

print("All tests passed!")
