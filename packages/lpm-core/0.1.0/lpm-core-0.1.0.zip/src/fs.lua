local M = {}

local function exec(cmd)
    local ok, _, code = os.execute(cmd .. " 2>/dev/null")
    return (ok and (code == 0 or code == true)) or false
end

function M.exists(path)
    local f = io.open(path, "r")
    if f then
        f:close()
        return true
    end
    return exec("test -e " .. path)
end

function M.mkdir(path)
    return exec("mkdir " .. path)
end

function M.mkdir_p(path)
    return exec("mkdir -p " .. path)
end

function M.remove(path)
    return exec("rm -rf " .. path)
end

function M.read_file(path)
    local file = io.open(path, "r")
    if not file then return nil end
    local content = file:read("*all")
    file:close()
    return content
end

function M.write_file(path, content)
    local file = io.open(path, "w")
    if not file then return false end
    file:write(content)
    file:close()
    return true
end

function M.list_dir(path)
    local entries = {}
    local p = io.popen("ls -1 " .. path .. " 2>/dev/null")
    if not p then return entries end
    
    for name in p:lines() do
        table.insert(entries, name)
    end
    p:close()
    return entries
end

function M.copy_file(src, dst)
    local content = M.read_file(src)
    if not content then return false end
    return M.write_file(dst, content)
end

local function copy_entry(src, dst)
    if M.is_dir(src) then
        return M.copy_dir(src, dst)
    end
    return M.copy_file(src, dst)
end

function M.copy_dir(src, dst)
    if not M.exists(src) then return false end
    if not M.mkdir_p(dst) then return false end
    
    local entries = M.list_dir(src)
    for _, entry in ipairs(entries) do
        local src_path = src .. "/" .. entry
        local dst_path = dst .. "/" .. entry
        
        if not copy_entry(src_path, dst_path) then
            return false
        end
    end
    
    return true
end

function M.is_dir(path)
    return exec("test -d " .. path)
end

function M.is_file(path)
    return exec("test -f " .. path)
end

function M.mtime(path)
    local p = io.popen("stat -c %Y " .. path .. " 2>/dev/null")
    if not p then return nil end
    local time = p:read("*n")
    p:close()
    return time
end

return M
