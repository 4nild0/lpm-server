local M = {}
local toml = require("toml")
local fs = require("fs")
local path = require("path")
local err = require("error")

local METADATA_FILE = "project.toml"

function M.load(dir)
    local file_path = path.join(dir, METADATA_FILE)
    if not fs.exists(file_path) then
        return nil, err.new(err.codes.FILE_NOT_FOUND, "No " .. METADATA_FILE .. " found in " .. dir)
    end
    
    local content = fs.read_file(file_path)
    if not content then
        return nil, err.new(err.codes.GENERIC_ERROR, "Failed to read " .. file_path)
    end
    
    local data = toml.decode(content)
    if not data then
        return nil, err.new(err.codes.PARSE_ERROR, "Failed to parse " .. file_path)
    end
    
    if not data.name then
        return nil, err.new(err.codes.INVALID_METADATA, "Missing 'name' in " .. file_path)
    end
    
    if not data.version then
        return nil, err.new(err.codes.INVALID_METADATA, "Missing 'version' in " .. file_path)
    end
    
    return data
end

function M.save(dir, data)
    local file_path = path.join(dir, METADATA_FILE)
    local content = toml.encode(data)
    if not fs.write_file(file_path, content) then
        return nil, err.new(err.codes.GENERIC_ERROR, "Failed to write " .. file_path)
    end
    return true
end

return M
