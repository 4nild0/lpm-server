local M = {}

M.codes = {
    OK = 0,
    GENERIC_ERROR = 1,
    INVALID_ARGUMENT = 2,
    FILE_NOT_FOUND = 3,
    PERMISSION_DENIED = 4,
    NETWORK_ERROR = 5,
    PARSE_ERROR = 6,
    INVALID_METADATA = 7,
    DEPENDENCY_ERROR = 8,
}

function M.new(code, message)
    return {
        code = code,
        message = message,
        __tostring = function(self)
            return string.format("Error %d: %s", self.code, self.message)
        end
    }
end

function M.is_error(obj)
    return type(obj) == "table" and obj.code and obj.message
end

return M
