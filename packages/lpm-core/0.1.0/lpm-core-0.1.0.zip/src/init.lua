local environment_loader = require("foundation.environment_loader")

local lpm_core = {}
lpm_core.EnvLoader = environment_loader

return lpm_core
