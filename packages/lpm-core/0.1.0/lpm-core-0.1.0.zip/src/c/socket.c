#include <lua.h>
#include <lauxlib.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <errno.h>
#include <netdb.h>

static int socket_create(lua_State *L) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        lua_pushnil(L);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    lua_pushinteger(L, sock);
    return 1;
}

static int socket_bind(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    const char *host = luaL_checkstring(L, 2);
    int port = luaL_checkinteger(L, 3);
    
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(host);
    
    if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushboolean(L, 1);
    return 1;
}

static int socket_listen(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    int backlog = luaL_optinteger(L, 2, 10);
    
    if (listen(sock, backlog) < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushboolean(L, 1);
    return 1;
}

static int socket_accept(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    
    int client = accept(sock, (struct sockaddr*)&client_addr, &addr_len);
    if (client < 0) {
        lua_pushnil(L);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushinteger(L, client);
    lua_pushstring(L, inet_ntoa(client_addr.sin_addr));
    return 2;
}

static int socket_connect(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    const char *host = luaL_checkstring(L, 2);
    int port = luaL_checkinteger(L, 3);
    
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    
    struct hostent *he = gethostbyname(host);
    if (he) {
        memcpy(&addr.sin_addr, he->h_addr_list[0], he->h_length);
    } else {
        addr.sin_addr.s_addr = inet_addr(host);
    }
    
    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushboolean(L, 1);
    return 1;
}

static int socket_recv(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    int size = luaL_optinteger(L, 2, 4096);
    
    char *buffer = malloc(size);
    if (!buffer) {
        lua_pushnil(L);
        lua_pushstring(L, "Memory allocation failed");
        return 2;
    }
    
    int received = recv(sock, buffer, size, 0);
    if (received < 0) {
        free(buffer);
        lua_pushnil(L);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushlstring(L, buffer, received);
    free(buffer);
    return 1;
}

static int socket_send(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    size_t len;
    const char *data = luaL_checklstring(L, 2, &len);
    
    int sent = send(sock, data, len, 0);
    if (sent < 0) {
        lua_pushnil(L);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushinteger(L, sent);
    return 1;
}

static int socket_close(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    close(sock);
    lua_pushboolean(L, 1);
    return 1;
}

static int socket_setnonblocking(lua_State *L) {
    int sock = luaL_checkinteger(L, 1);
    int flags = fcntl(sock, F_GETFL, 0);
    if (flags < 0 || fcntl(sock, F_SETFL, flags | O_NONBLOCK) < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    lua_pushboolean(L, 1);
    return 1;
}

static const luaL_Reg socketlib[] = {
    {"create", socket_create},
    {"bind", socket_bind},
    {"listen", socket_listen},
    {"accept", socket_accept},
    {"connect", socket_connect},
    {"recv", socket_recv},
    {"send", socket_send},
    {"close", socket_close},
    {"setnonblocking", socket_setnonblocking},
    {NULL, NULL}
};

int luaopen_lpm_socket(lua_State *L) {
    luaL_newlib(L, socketlib);
    return 1;
}
