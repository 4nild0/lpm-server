local M = {}

M.sep = package.config:sub(1,1)

function M.join(...)
    local parts = {...}
    local path = ""
    
    for i, part in ipairs(parts) do
        if i > 1 then
            part = part:gsub("^[/\\]+", ""):gsub("[/\\]+$", "")
            if part ~= "" then
                path = path .. M.sep .. part
            end
        end
        if i == 1 then
            path = part
        end
    end
    
    return (path:gsub("[/\\]+", M.sep))
end

function M.dirname(path)
    local dir = path:match("(.*)[/\\]")
    return dir or "."
end

function M.basename(path)
    return path:match(".*[/\\](.+)$") or path
end

function M.extension(path)
    return path:match("%.([^.]*)$") or ""
end

local function handle_parent(parts)
    if #parts > 0 then
        table.remove(parts)
    end
end

local function handle_part(parts, part)
    if part == ".." then
        handle_parent(parts)
        return
    end
    if part ~= "." then
        table.insert(parts, part)
    end
end

function M.normalize(path)
    local parts = {}
    for part in path:gmatch("[^/\\]+") do
        handle_part(parts, part)
    end
    
    local is_absolute = path:match("^[/\\]")
    local result = table.concat(parts, M.sep)
    
    if is_absolute then
        return M.sep .. result
    end
    return result
end

function M.is_absolute(path)
    return path:match("^[/\\]") ~= nil or path:match("^%a:[/\\]") ~= nil
end

function M.resolve(base, ...)
    local path = M.join(...)
    
    if M.is_absolute(path) then
        return M.normalize(path)
    end
    return M.normalize(M.join(base, path))
end

function M.relative(from, to)
    if from == to then return "." end
    
    local function split(path)
        local parts = {}
        for part in path:gmatch("[^/\\]+") do
            table.insert(parts, part)
        end
        return parts
    end
    
    local from_parts = split(M.normalize(from))
    local to_parts = split(M.normalize(to))
    
    local i = 1
    while from_parts[i] and to_parts[i] and from_parts[i] == to_parts[i] do
        i = i + 1
    end
    
    local rel_parts = {}
    
    for j = i, #from_parts do
        table.insert(rel_parts, "..")
    end
    
    for j = i, #to_parts do
        table.insert(rel_parts, to_parts[j])
    end
    
    return table.concat(rel_parts, M.sep)
end

return M
