local M = {}

local function is_array(t)
    if type(t) ~= "table" then return false end
    local i = 0
    for _ in pairs(t) do
        i = i + 1
        if t[i] == nil then return false end
    end
    return true
end

local function escape_string(str)
    return str:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\n", "\\n"):gsub("\t", "\\t")
end

local function encode_table(arrays, sections, k, v)
    if is_array(v) then
        arrays[k] = v
        return
    end
    sections[k] = v
end

local function encode_value(result, k, v)
    local vtype = type(v)
    
    if vtype == "table" then
        return nil
    end
    
    if vtype == "string" then
        table.insert(result, string.format('%s = "%s"', k, escape_string(v)))
        return
    end
    
    if vtype == "number" or vtype == "boolean" then
        table.insert(result, string.format("%s = %s", k, tostring(v)))
    end
end

local function encode_array_item(result, item)
    if type(item) == "string" then
        table.insert(result, string.format('  "%s",', escape_string(item)))
        return
    end
    table.insert(result, string.format("  %s,", tostring(item)))
end

function M.encode(tbl)
    local result = {}
    local sections = {}
    local arrays = {}
    
    for k, v in pairs(tbl) do
        if type(v) == "table" then
            encode_table(arrays, sections, k, v)
        end
        encode_value(result, k, v)
    end
    
    for k, v in pairs(arrays) do
        table.insert(result, string.format("%s = [", k))
        for _, item in ipairs(v) do
            encode_array_item(result, item)
        end
        table.insert(result, "]")
    end
    
    for section, section_tbl in pairs(sections) do
        table.insert(result, string.format("\n[%s]", section))
        for sk, sv in pairs(section_tbl) do
            encode_value(result, sk, sv)
        end
    end
    
    return table.concat(result, "\n")
end

local function parse_section(line, result)
    local section = line:match("^%[([^%]]+)%]%s*$")
    if section then
        result[section] = result[section] or {}
        return result[section]
    end
    return nil
end

local function parse_array(value)
    if not value:match("^%s*%[") then
        return nil
    end
    
    local items = {}
    for item in value:gmatch("[^,%s]+") do
        item = item:gsub("^%s*[\"']?([^\"']*)[\"']?%s*$", "%1")
        table.insert(items, item)
    end
    return items
end

local function parse_string(value)
    return value:match("^%s*[\"']?([^\"']*)[\"']?%s*$")
end

local function parse_key_value(line, current_section)
    local key, value = line:match("^([^=]+)%s*=%s*(.+)$")
    if not key then return end
    
    key = key:match("^%s*(.-)%s*$")
    
    local array_items = parse_array(value)
    if array_items then
        current_section[key] = array_items
        return
    end
    
    current_section[key] = parse_string(value)
end

function M.decode(str)
    local result = {}
    local current_section = result
    
    for line in str:gmatch("[^\r\n]+") do
        line = line:gsub("%s*#.*$", ""):match("^%s*(.-)%s*$")
        if line ~= "" then
            local new_section = parse_section(line, result)
            if new_section then
                current_section = new_section
            end
            
            if not new_section then
                parse_key_value(line, current_section)
            end
        end
    end
    
    return result
end

return M
