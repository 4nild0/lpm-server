local environment_loader = {}

function environment_loader.load(file_path)
    local file = io.open(file_path or ".env", "r")
    if not file then
        return {}
    end

    local env = {}
    for line in file:lines() do
        local key, value = line:match("^([%w_]+)=(.*)$")
        if key and value then
            env[key] = value
        end
    end
    file:close()
    return env
end

return environment_loader

