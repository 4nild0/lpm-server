local path_resolver = {}

path_resolver.sep = package.config:sub(1,1)

function path_resolver.join(...)
    local parts = {...}
    local path = ""
    
    for i, part in ipairs(parts) do
        if i > 1 then
            part = part:gsub("^[/\\]+", ""):gsub("[/\\]+$", "")
            if part ~= "" then
                path = path .. path_resolver.sep .. part
            end
        end
        if i == 1 then
            path = part
        end
    end
    
    return (path:gsub("[/\\]+", path_resolver.sep))
end

function path_resolver.dirname(path)
    local dir = path:match("(.*)[/\\]")
    return dir or "."
end

function path_resolver.basename(path)
    return path:match(".*[/\\](.+)$") or path
end

function path_resolver.extension(path)
    return path:match("%.([^.]*)$") or ""
end

local function handle_parent(parts)
    if #parts > 0 then
        table.remove(parts)
    end
end

local function handle_part(parts, part)
    if part == ".." then
        handle_parent(parts)
        return
    end
    if part ~= "." then
        table.insert(parts, part)
    end
end

function path_resolver.normalize(path)
    local parts = {}
    for part in path:gmatch("[^/\\]+") do
        handle_part(parts, part)
    end
    
    local is_absolute = path:match("^[/\\]")
    local result = table.concat(parts, path_resolver.sep)
    
    if is_absolute then
        return path_resolver.sep .. result
    end
    return result
end

function path_resolver.is_absolute(path)
    return path:match("^[/\\]") ~= nil or path:match("^%a:[/\\]") ~= nil
end

function path_resolver.resolve(base, ...)
    local path = path_resolver.join(...)
    
    if path_resolver.is_absolute(path) then
        return path_resolver.normalize(path)
    end
    return path_resolver.normalize(path_resolver.join(base, path))
end

function path_resolver.relative(from, to)
    if from == to then return "." end
    
    local function split(path)
        local parts = {}
        for part in path:gmatch("[^/\\]+") do
            table.insert(parts, part)
        end
        return parts
    end
    
    local from_parts = split(path_resolver.normalize(from))
    local to_parts = split(path_resolver.normalize(to))
    
    local i = 1
    while from_parts[i] and to_parts[i] and from_parts[i] == to_parts[i] do
        i = i + 1
    end
    
    local rel_parts = {}
    
    for j = i, #from_parts do
        table.insert(rel_parts, "..")
    end
    
    for j = i, #to_parts do
        table.insert(rel_parts, to_parts[j])
    end
    
    return table.concat(rel_parts, path_resolver.sep)
end

return path_resolver

