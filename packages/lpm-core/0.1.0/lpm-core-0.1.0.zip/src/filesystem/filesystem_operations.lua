local filesystem_operations = {}

local function exec(cmd)
    local ok, _, code = os.execute(cmd .. " 2>/dev/null")
    return (ok and (code == 0 or code == true)) or false
end

function filesystem_operations.exists(path)
    local f = io.open(path, "r")
    if f then
        f:close()
        return true
    end
    return exec("test -e " .. path)
end

function filesystem_operations.mkdir(path)
    return exec("mkdir " .. path)
end

function filesystem_operations.mkdir_p(path)
    return exec("mkdir -p " .. path)
end

function filesystem_operations.remove(path)
    return exec("rm -rf " .. path)
end

function filesystem_operations.read_file(path)
    local file = io.open(path, "r")
    if not file then return nil end
    local content = file:read("*all")
    file:close()
    return content
end

function filesystem_operations.write_file(path, content)
    local file = io.open(path, "w")
    if not file then return false end
    file:write(content)
    file:close()
    return true
end

function filesystem_operations.list_dir(path)
    local entries = {}
    local p = io.popen("ls -1 " .. path .. " 2>/dev/null")
    if not p then return entries end
    
    for name in p:lines() do
        table.insert(entries, name)
    end
    p:close()
    return entries
end

function filesystem_operations.copy_file(src, dst)
    local content = filesystem_operations.read_file(src)
    if not content then return false end
    return filesystem_operations.write_file(dst, content)
end

local function copy_entry(src, dst)
    if filesystem_operations.is_dir(src) then
        return filesystem_operations.copy_dir(src, dst)
    end
    return filesystem_operations.copy_file(src, dst)
end

function filesystem_operations.copy_dir(src, dst)
    if not filesystem_operations.exists(src) then return false end
    if not filesystem_operations.mkdir_p(dst) then return false end
    
    local entries = filesystem_operations.list_dir(src)
    for _, entry in ipairs(entries) do
        local src_path = src .. "/" .. entry
        local dst_path = dst .. "/" .. entry
        
        if not copy_entry(src_path, dst_path) then
            return false
        end
    end
    
    return true
end

function filesystem_operations.is_dir(path)
    return exec("test -d " .. path)
end

function filesystem_operations.is_file(path)
    return exec("test -f " .. path)
end

function filesystem_operations.mtime(path)
    local p = io.popen("stat -c %Y " .. path .. " 2>/dev/null")
    if not p then return nil end
    local time = p:read("*n")
    p:close()
    return time
end

return filesystem_operations

