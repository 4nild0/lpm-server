local package_metadata = {}
local toml_parser = require("services.toml_parser")
local filesystem_operations = require("filesystem.filesystem_operations")
local path_resolver = require("filesystem.path_resolver")
local error_handler = require("foundation.error_handler")

local METADATA_FILE = "project.toml"

function package_metadata.load(dir)
    local file_path = path_resolver.join(dir, METADATA_FILE)
    if not filesystem_operations.exists(file_path) then
        return nil, error_handler.new(error_handler.codes.FILE_NOT_FOUND, "No " .. METADATA_FILE .. " found in " .. dir)
    end
    
    local content = filesystem_operations.read_file(file_path)
    if not content then
        return nil, error_handler.new(error_handler.codes.GENERIC_ERROR, "Failed to read " .. file_path)
    end
    
    local data = toml_parser.decode(content)
    if not data then
        return nil, error_handler.new(error_handler.codes.PARSE_ERROR, "Failed to parse " .. file_path)
    end
    
    if not data.name then
        return nil, error_handler.new(error_handler.codes.INVALID_METADATA, "Missing 'name' in " .. file_path)
    end
    
    if not data.version then
        return nil, error_handler.new(error_handler.codes.INVALID_METADATA, "Missing 'version' in " .. file_path)
    end
    
    return data
end

function package_metadata.save(dir, data)
    local file_path = path_resolver.join(dir, METADATA_FILE)
    local content = toml_parser.encode(data)
    if not filesystem_operations.write_file(file_path, content) then
        return nil, error_handler.new(error_handler.codes.GENERIC_ERROR, "Failed to write " .. file_path)
    end
    return true
end

return package_metadata

