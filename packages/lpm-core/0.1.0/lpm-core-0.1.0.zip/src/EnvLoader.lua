local EnvLoader = {}

function EnvLoader.load()
    local file = io.open(".env", "r")
    if not file then
        return {}
    end

    local env = {}
    for line in file:lines() do
        local key, value = line:match("^([%w_]+)=(.*)$")
        if key and value then
            env[key] = value
        end
    end
    file:close()
    return env
end

return EnvLoader
