local module_finder = {}
local filesystem_operations = require("filesystem.filesystem_operations")
local path_resolver = require("filesystem.path_resolver")

local function process_file_module(modules, entry, full_path)
    if filesystem_operations.is_file(full_path) and path_resolver.extension(entry) == "lua" then
        local mod_name = entry:gsub("%.lua$", "")
        table.insert(modules, {
            name = mod_name,
            path = full_path,
            type = "file"
        })
    end
end

local function process_dir_module(modules, entry, full_path)
    if filesystem_operations.is_dir(full_path) then
        local init_file = path_resolver.join(full_path, "init.lua")
        if filesystem_operations.exists(init_file) then
            table.insert(modules, {
                name = entry,
                path = full_path,
                type = "directory"
            })
        end
    end
end

function module_finder.find_modules(src_dir)
    local modules = {}
    if not filesystem_operations.exists(src_dir) then return modules end
    
    local entries = filesystem_operations.list_dir(src_dir)
    for _, entry in ipairs(entries) do
        local full_path = path_resolver.join(src_dir, entry)
        process_file_module(modules, entry, full_path)
        process_dir_module(modules, entry, full_path)
    end
    
    return modules
end

return module_finder

