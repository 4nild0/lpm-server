local extension_finder = {}
local filesystem_operations = require("filesystem.filesystem_operations")
local path_resolver = require("filesystem.path_resolver")

function extension_finder.find_extensions(ext_dir)
    local extensions = {}
    if not filesystem_operations.exists(ext_dir) then return extensions end
    
    local entries = filesystem_operations.list_dir(ext_dir)
    for _, entry in ipairs(entries) do
        local full_path = path_resolver.join(ext_dir, entry)
        if filesystem_operations.is_file(full_path) and (path_resolver.extension(entry) == "so" or path_resolver.extension(entry) == "dll") then
            local ext_name = entry:gsub("%.so$", ""):gsub("%.dll$", "")
            table.insert(extensions, {
                name = ext_name,
                path = full_path,
                type = "binary"
            })
        end
    end
    
    return extensions
end

return extension_finder

