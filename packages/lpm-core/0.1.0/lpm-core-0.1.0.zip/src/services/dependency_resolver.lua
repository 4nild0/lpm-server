local dependency_resolver = {}
local toml_parser = require("services.toml_parser")
local filesystem_operations = require("filesystem.filesystem_operations")
local package_metadata = require("domain.package_metadata")

function dependency_resolver.load_dependencies(project_dir)
    local metadata, err = package_metadata.load(project_dir)
    if not metadata then
        return {}, {}
    end
    
    local runtime_deps = metadata.dependencies or {}
    local test_deps = metadata["test-dependencies"] or {}
    
    return runtime_deps, test_deps
end

function dependency_resolver.merge_dependencies(runtime_deps, test_deps)
    local all_deps = {}
    
    for name, version in pairs(runtime_deps) do
        all_deps[name] = version
    end
    
    for name, version in pairs(test_deps) do
        if not all_deps[name] then
            all_deps[name] = version
        end
    end
    
    return all_deps
end

return dependency_resolver

