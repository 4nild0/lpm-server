local M = {}
local fs = require("fs")
local path = require("path")

function M.find_extensions(ext_dir)
    local extensions = {}
    if not fs.exists(ext_dir) then return extensions end
    
    local entries = fs.list_dir(ext_dir)
    for _, entry in ipairs(entries) do
        local full_path = path.join(ext_dir, entry)
        if fs.is_file(full_path) and (path.extension(entry) == "so" or path.extension(entry) == "dll") then
            local ext_name = entry:gsub("%.so$", ""):gsub("%.dll$", "")
            table.insert(extensions, {
                name = ext_name,
                path = full_path,
                type = "binary"
            })
        end
    end
    
    return extensions
end

return M
