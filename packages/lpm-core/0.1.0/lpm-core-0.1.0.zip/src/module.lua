local M = {}
local fs = require("fs")
local path = require("path")

local function process_file_module(modules, entry, full_path)
    if fs.is_file(full_path) and path.extension(entry) == "lua" then
        local mod_name = entry:gsub("%.lua$", "")
        table.insert(modules, {
            name = mod_name,
            path = full_path,
            type = "file"
        })
    end
end

local function process_dir_module(modules, entry, full_path)
    if fs.is_dir(full_path) then
        local init_file = path.join(full_path, "init.lua")
        if fs.exists(init_file) then
            table.insert(modules, {
                name = entry,
                path = full_path,
                type = "directory"
            })
        end
    end
end

function M.find_modules(src_dir)
    local modules = {}
    if not fs.exists(src_dir) then return modules end
    
    local entries = fs.list_dir(src_dir)
    for _, entry in ipairs(entries) do
        local full_path = path.join(src_dir, entry)
        process_file_module(modules, entry, full_path)
        process_dir_module(modules, entry, full_path)
    end
    
    return modules
end

return M
