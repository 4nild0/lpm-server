#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#define SOCKET_META "lsocket.socket"

typedef struct {
    int fd;
    int is_server;
} lsocket_t;

static lsocket_t* check_socket(lua_State *L, int index) {
    return (lsocket_t*)luaL_checkudata(L, index, SOCKET_META);
}

static int lsocket_create(lua_State *L) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        lua_pushnil(L);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    int opt = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    lsocket_t *sock = (lsocket_t*)lua_newuserdata(L, sizeof(lsocket_t));
    sock->fd = fd;
    sock->is_server = 0;
    
    luaL_getmetatable(L, SOCKET_META);
    lua_setmetatable(L, -2);
    
    return 1;
}

static int lsocket_bind(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    int port = luaL_checkinteger(L, 2);
    const char *host = luaL_optstring(L, 3, "0.0.0.0");
    
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(host);
    
    int opt = 1;
    setsockopt(sock->fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    if (bind(sock->fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    sock->is_server = 1;
    lua_pushboolean(L, 1);
    return 1;
}

static int lsocket_listen(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    int backlog = luaL_optinteger(L, 2, 10);
    
    if (listen(sock->fd, backlog) < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushboolean(L, 1);
    return 1;
}

static int lsocket_accept(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    
    int client_fd = accept(sock->fd, (struct sockaddr*)&client_addr, &addr_len);
    if (client_fd < 0) {
        lua_pushnil(L);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lsocket_t *client = (lsocket_t*)lua_newuserdata(L, sizeof(lsocket_t));
    client->fd = client_fd;
    client->is_server = 0;
    
    luaL_getmetatable(L, SOCKET_META);
    lua_setmetatable(L, -2);
    
    return 1;
}

static int lsocket_recv(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    int size = luaL_optinteger(L, 2, 4096);
    
    char *buffer = (char*)malloc(size);
    if (!buffer) {
        lua_pushnil(L);
        lua_pushstring(L, "out of memory");
        return 2;
    }
    
    ssize_t n = recv(sock->fd, buffer, size, 0);
    if (n < 0) {
        free(buffer);
        lua_pushnil(L);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    if (n == 0) {
        free(buffer);
        lua_pushnil(L);
        return 1;
    }
    
    lua_pushlstring(L, buffer, n);
    free(buffer);
    return 1;
}

static int lsocket_send(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    size_t len;
    const char *data = luaL_checklstring(L, 2, &len);
    
    ssize_t n = send(sock->fd, data, len, 0);
    if (n < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushinteger(L, n);
    return 1;
}

static int lsocket_connect(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    const char *host = luaL_checkstring(L, 2);
    int port = luaL_checkinteger(L, 3);
    
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(host);
    
    if (connect(sock->fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        lua_pushboolean(L, 0);
        lua_pushstring(L, strerror(errno));
        return 2;
    }
    
    lua_pushboolean(L, 1);
    return 1;
}

static int lsocket_close(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    
    if (sock->fd >= 0) {
        close(sock->fd);
        sock->fd = -1;
    }
    
    lua_pushboolean(L, 1);
    return 1;
}

static int lsocket_gc(lua_State *L) {
    lsocket_t *sock = check_socket(L, 1);
    if (sock->fd >= 0) {
        close(sock->fd);
        sock->fd = -1;
    }
    return 0;
}

static const luaL_Reg socket_methods[] = {
    {"bind", lsocket_bind},
    {"listen", lsocket_listen},
    {"accept", lsocket_accept},
    {"connect", lsocket_connect},
    {"recv", lsocket_recv},
    {"send", lsocket_send},
    {"close", lsocket_close},
    {NULL, NULL}
};

static const luaL_Reg socket_funcs[] = {
    {"create", lsocket_create},
    {NULL, NULL}
};

int luaopen_lsocket(lua_State *L) {
    luaL_newmetatable(L, SOCKET_META);
    lua_pushvalue(L, -1);
    lua_setfield(L, -2, "__index");
    lua_pushcfunction(L, lsocket_gc);
    lua_setfield(L, -2, "__gc");
    luaL_setfuncs(L, socket_methods, 0);
    
    luaL_newlib(L, socket_funcs);
    return 1;
}
