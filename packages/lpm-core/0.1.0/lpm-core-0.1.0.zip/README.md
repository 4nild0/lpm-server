# LPM Core

Módulo central do LPM (Lua Package Manager) contendo funcionalidades compartilhadas entre os componentes do ecossistema.

## Descrição

O `lpm-core` fornece as funcionalidades fundamentais utilizadas por todos os componentes do LPM, incluindo operações de sistema de arquivos, manipulação de caminhos, parsing de TOML, carregamento de variáveis de ambiente e utilitários para módulos.

## Módulos Principais

- **EnvLoader.lua**: Carregamento de variáveis de ambiente a partir de arquivos `.env`
- **fs.lua**: Operações de sistema de arquivos (criar, ler, escrever, listar, verificar existência)
- **path.lua**: Manipulação de caminhos e resolução de diretórios
- **toml.lua**: Parser para arquivos TOML
- **module.lua**: Utilitários para carregamento de módulos
- **error.lua**: Tratamento de erros padronizado
- **extension.lua**: Suporte a extensões nativas (C)
- **metadata.lua**: Manipulação de metadados de pacotes

## Instalação

O `lpm-core` é uma dependência dos outros componentes do LPM e é instalado automaticamente quando você instala `lpm-cli`, `lpm-server` ou `lpm-page`.

## Uso Básico

```lua
-- Carregando o módulo principal
local Core = require("lpm-core")

-- Exemplo de uso do EnvLoader
local env = Core.EnvLoader.load(".env")

-- Exemplo de uso do módulo de arquivos
local fs = require("fs")
local content = fs.read_file("arquivo.txt")
```

## Estrutura do Projeto

```
lpm-core/
├── src/
│   ├── EnvLoader.lua   # Carregamento de variáveis de ambiente
│   ├── error.lua       # Tratamento de erros
│   ├── extension.lua   # Suporte a extensões nativas
│   ├── fs.lua          # Operações de sistema de arquivos
│   ├── init.lua        # Ponto de entrada do módulo
│   ├── metadata.lua    # Manipulação de metadados
│   ├── module.lua      # Utilitários para módulos
│   ├── path.lua        # Manipulação de caminhos
│   └── toml.lua        # Parser TOML
├── ext/                # Código fonte de extensões nativas
│   └── lsocket.c       # Implementação de socket em C
├── tests/              # Testes unitários
│   └── test_core.lua
├── project.toml        # Manifesto do projeto
└── Makefile            # Build de extensões nativas
```

## Requisitos

- Lua 5.1 ou superior
- Compilador C (para extensões nativas)

## Desenvolvimento

Para contribuir com o desenvolvimento:

1. Faça um fork do repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-funcionalidade`)
3. Faça commit das suas alterações (`git commit -am 'Adiciona nova funcionalidade'`)
4. Faça push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## Licença

MIT License
