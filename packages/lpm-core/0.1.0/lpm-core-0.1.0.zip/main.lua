local info = debug.getinfo(1, "S")
local path = info.source:sub(2):match("(.*/)") or "./"
package.path = path .. "src/?.lua;" .. path .. "src/?/init.lua;" .. package.path

local Core = require("init")
_G.ENV = Core.EnvLoader.load()

return Core
